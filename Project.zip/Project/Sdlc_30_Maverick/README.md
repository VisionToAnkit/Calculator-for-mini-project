# Sdlc_30_Maverick

This is your kickstart module into learning the basics of Cryptography. Learn and practice the basic substituition techniques

Caesar Cipher
Monoalphabetic Cipher
Playfair Cipher
Hill Cipher
Polyalphabetic Cipher
# Requirements


## Introduction
 
The aim of this application is to throw light on the basics of Cryptography and Learn & Practice basic Encryption and Decryption through substitution techniques. Many Cyber Security courses expect students to have an understanding of essential concepts underlying Cryptographic system. 
The application covers five substitution techniques: Caesar Cipher, Monoalphabetic Cipher, Playfair Cipher, Hill Cipher and Polyalphabetic Cipher.